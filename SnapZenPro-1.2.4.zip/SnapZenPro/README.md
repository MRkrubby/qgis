# SnapZen Pro v1.2.3 (QGIS Plugin)

- **UnboundLocalError fix**: geen gebruik meer van `base_cfg`, `QgsSnappingConfig()` wordt direct en expliciet aangemaakt.
- **Toolbar + zichtbare SVG-iconen**, **Plugins-menu**, **instellingen-dock** (open by default).
- Lokale `QgsSnappingConfig` + **robuste `QgsSnappingUtils` fallback**.
